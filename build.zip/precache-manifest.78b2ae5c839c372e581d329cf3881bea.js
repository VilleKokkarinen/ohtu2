self.__precacheManifest = [
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "80a2ab871a60453365bb",
    "url": "/static/js/main.abfad986.chunk.js"
  },
  {
    "revision": "897f662436b425a71d37",
    "url": "/static/js/2.d486341e.chunk.js"
  },
  {
    "revision": "80a2ab871a60453365bb",
    "url": "/static/css/main.f64c4fd9.chunk.css"
  },
  {
    "revision": "ce81df3000549d0c619ca1af89780a1b",
    "url": "/index.html"
  }
];